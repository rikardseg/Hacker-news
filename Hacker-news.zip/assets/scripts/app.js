let dropDown = document.querySelector(".sortoptions");

dropDown.addEventListener("click", function () {
  {
    let dropDown = document.querySelector(".dropdown");
    dropDown.classList.toggle("on");
  }
});
