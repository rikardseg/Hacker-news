// const deleteButton = document.querySelector(".delete");

// deleteButton.addEventListener("click", function () {
//   if (!confirm("Are you sure?")) {
//     return false;
//   }
// });
