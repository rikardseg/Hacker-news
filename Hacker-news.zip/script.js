// const login = document.querySelector("li:last-child");

// login.addEventListener("click", () => {
//   window.location.replace("index2.html");
// });
